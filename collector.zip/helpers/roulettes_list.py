# roulettes_list.py
roulettes = [
    #{"slug": "casino-malta-roulette", "name": "Casino Malta Roulette", "url": "https://bateu.bet.br/games/evolution/casino-malta-roulette"},
    {"slug": "evolution-greek-roulette", "name": "Greek Roulette", "url": "https://bateu.bet.br"},
    {"slug": "lightning-roulette", "name": "Lightning Roulette", "url": "https://bateu.bet.br/games/evolution/lightning-roulette"},
   
    {"slug": "evolution-ruleta-en-vivo", "name": "Ruleta en Vivo", "url": "https://bateu.bet.br"},
    {"slug": "evolution-emperor-roulette", "name": "Emperor Roulette", "url": "https://bateu.bet.br"},
    {"slug": "hindi-lightning-roulette", "name": "Hindi Lightning Roulette", "url": "https://bateu.bet.br"},
    {"slug": "ruleta-bola-rapida-en-vivo", "name": "Ruleta Bola Rápida en Vivo", "url": "https://bateu.bet.br"},
    {"slug": "evolution-turkey-roulette", "name": "Turkey Roulette", "url": "https://bateu.bet.br"},
    {"slug": "evolution-football-studio-roulette", "name": "Football Studio Roulette", "url": "https://bateu.bet.br"},
    {"slug": "evolution-japanese-roulette", "name": "Japanese Roulette", "url": "https://bateu.bet.br"},
    {"slug": "evolution-ruletka-live", "name": "Ruletka Live", "url": "https://bateu.bet.br"},
    {"slug": "italia-lightning-roulette", "name": "Italia Lightning Roulette", "url": "https://bateu.bet.br"},
]